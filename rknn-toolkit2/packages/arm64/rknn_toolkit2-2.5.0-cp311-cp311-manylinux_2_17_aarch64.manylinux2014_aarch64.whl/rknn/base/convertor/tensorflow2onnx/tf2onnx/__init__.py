# SPDX-License-Identifier: Apache-2.0

"""tf2onnx package."""

__all__ = ["utils", "graph_matcher", "graph", "graph_builder",
           "tfonnx", "shape_inference", "schemas", "tf_utils", "tf_loader", "convert"]

import onnx
from .version import git_version, version as __version__
from . import verbose_logging as logging
import sys
sys.path.insert(0, sys.path[-1])    # 避免系统也安装了tf2onnx而调用系统的tf2onnx
from tf2onnx import tfonnx, utils, graph, graph_builder, graph_matcher, shape_inference, schemas, convert  # pylint: disable=wrong-import-order
